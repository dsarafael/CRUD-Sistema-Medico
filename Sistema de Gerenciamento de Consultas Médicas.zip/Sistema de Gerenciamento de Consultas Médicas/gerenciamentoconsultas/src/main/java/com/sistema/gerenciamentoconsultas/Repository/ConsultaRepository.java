package com.sistema.gerenciamentoconsultas.Repository;

import com.sistema.gerenciamentoconsultas.Entities.Consulta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConsultaRepository extends JpaRepository<Consulta, Long> {
    // Estende a interface JpaRepository, indicando que trata-se de um repositório para a entidade Consulta
    // O segundo parâmetro <Consulta, Long> indica que a entidade é Consulta e o tipo da chave primária é Long
}
