package com.sistema.gerenciamentoconsultas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsultasMedicasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsultasMedicasApplication.class, args);
	}

}
