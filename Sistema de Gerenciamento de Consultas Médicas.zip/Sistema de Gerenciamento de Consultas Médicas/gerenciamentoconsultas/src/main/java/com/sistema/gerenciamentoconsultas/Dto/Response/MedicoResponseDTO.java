package com.sistema.gerenciamentoconsultas.Dto.Response;

import com.sistema.gerenciamentoconsultas.Entities.Medico;
import lombok.Getter;

@Getter
public class MedicoResponseDTO {
    private Long id;
    private String nome;
    private String crm;
    private String especialidade;

    public MedicoResponseDTO(Medico medico) {
        this.id = medico.getId();
        this.nome = medico.getNome();
        this.crm = medico.getCrm();
        this.especialidade = medico.getEspecialidade();
    }
}
