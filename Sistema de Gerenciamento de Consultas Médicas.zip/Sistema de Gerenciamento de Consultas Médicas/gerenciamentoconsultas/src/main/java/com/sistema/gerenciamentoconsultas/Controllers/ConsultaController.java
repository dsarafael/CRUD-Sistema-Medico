package com.sistema.gerenciamentoconsultas.Controllers;

import com.sistema.gerenciamentoconsultas.Dto.Request.ConsultaRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.ConsultaResponseDTO;
import com.sistema.gerenciamentoconsultas.service.ConsultaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consultas")
@RequiredArgsConstructor
public class ConsultaController {

    private final ConsultaService consultaService;

    @GetMapping("/{id}")
    public ResponseEntity<ConsultaResponseDTO> findById(@PathVariable Long id) {
        ConsultaResponseDTO consulta = consultaService.findById(id);
        return ResponseEntity.ok(consulta);
    }

    @GetMapping
    public ResponseEntity<List<ConsultaResponseDTO>> findAll() {
        List<ConsultaResponseDTO> consultas = consultaService.findAll();
        return ResponseEntity.ok(consultas);
    }

    @PostMapping
    public ResponseEntity<ConsultaResponseDTO> register(@RequestBody ConsultaRequestDTO consultaRequestDTO) {
        ConsultaResponseDTO novaConsulta = consultaService.register(consultaRequestDTO);
        return new ResponseEntity<>(novaConsulta, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ConsultaResponseDTO> update(@PathVariable Long id, @RequestBody ConsultaRequestDTO consultaRequestDTO) {
        ConsultaResponseDTO consultaAtualizada = consultaService.update(id, consultaRequestDTO);
        return ResponseEntity.ok(consultaAtualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        String response = consultaService.delete(id);
        return ResponseEntity.ok(response);
    }
}
