package com.sistema.gerenciamentoconsultas.service;

import com.sistema.gerenciamentoconsultas.Dto.Request.PacienteRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.PacienteResponseDTO;

import java.util.List;

public interface PacienteService {
    PacienteResponseDTO findById(Long id);

    List<PacienteResponseDTO> findAll();

    PacienteResponseDTO register(PacienteRequestDTO pacienteDTO);

    PacienteResponseDTO update(Long id, PacienteRequestDTO pacienteDTO);

    String delete(Long id);
}
