package com.sistema.gerenciamentoconsultas.service;

import com.sistema.gerenciamentoconsultas.Dto.Request.ConsultaRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.ConsultaResponseDTO;

import java.util.List;

public interface ConsultaService {
    ConsultaResponseDTO findById(Long id);

    List<ConsultaResponseDTO> findAll();

    ConsultaResponseDTO register(ConsultaRequestDTO consultaDTO);

    ConsultaResponseDTO update(Long id, ConsultaRequestDTO consultaDTO);

    String delete(Long id);
}
