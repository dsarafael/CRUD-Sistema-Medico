package com.sistema.gerenciamentoconsultas.Util;

import com.sistema.gerenciamentoconsultas.Dto.Request.MedicoRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.MedicoResponseDTO;
import com.sistema.gerenciamentoconsultas.Entities.Medico;
import org.springframework.stereotype.Component;

@Component
public class MedicoMapper {

    public Medico toMedico(MedicoRequestDTO medicoDTO) {
        return Medico.builder()
                .nome(medicoDTO.getNome())
                .crm(medicoDTO.getCrm())
                .especialidade(medicoDTO.getEspecialidade())
                .build();
    }

    public MedicoResponseDTO toMedicoDTO(Medico medico) {
        return new MedicoResponseDTO(medico);
    }

    public void updateMedicoData(Medico medico, MedicoRequestDTO medicoDTO) {
        medico.setNome(medicoDTO.getNome());
        medico.setCrm(medicoDTO.getCrm());
        medico.setEspecialidade(medicoDTO.getEspecialidade());
    }
}
