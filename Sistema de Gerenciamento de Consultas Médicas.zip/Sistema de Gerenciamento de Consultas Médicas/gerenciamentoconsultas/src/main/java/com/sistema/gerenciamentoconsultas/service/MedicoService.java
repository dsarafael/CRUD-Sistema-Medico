package com.sistema.gerenciamentoconsultas.service;

import com.sistema.gerenciamentoconsultas.Dto.Request.MedicoRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.MedicoResponseDTO;

import java.util.List;

public interface MedicoService {
    MedicoResponseDTO findById(Long id);

    List<MedicoResponseDTO> findAll();

    MedicoResponseDTO register(MedicoRequestDTO medicoDTO);

    MedicoResponseDTO update(Long id, MedicoRequestDTO medicoDTO);

    String delete(Long id);
}
