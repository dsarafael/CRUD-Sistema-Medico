package com.sistema.gerenciamentoconsultas.Repository;

import com.sistema.gerenciamentoconsultas.Entities.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {
    // Estende a interface JpaRepository, indicando que trata-se de um repositório para a entidade Paciente
    // O segundo parâmetro <Paciente, Long> indica que a entidade é Paciente e o tipo da chave primária é Long
}
