package com.sistema.gerenciamentoconsultas.service;

import com.sistema.gerenciamentoconsultas.Dto.Request.ConsultaRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.ConsultaResponseDTO;
import com.sistema.gerenciamentoconsultas.Entities.Consulta;
import com.sistema.gerenciamentoconsultas.Repository.ConsultaRepository;
import com.sistema.gerenciamentoconsultas.Util.ConsultaMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ConsultaServiceImpl implements ConsultaService {

    private final ConsultaRepository consultaRepository;
    private final ConsultaMapper consultaMapper;

    @Override
    public ConsultaResponseDTO findById(Long id) {
        Consulta consulta = returnConsulta(id);
        return consultaMapper.toConsultaDTO(consulta);
    }

    @Override
    public List<ConsultaResponseDTO> findAll() {
        List<Consulta> consultas = consultaRepository.findAll();
        return consultas.stream().map(consultaMapper::toConsultaDTO).collect(Collectors.toList());
    }

    @Override
    public ConsultaResponseDTO register(ConsultaRequestDTO consultaDTO) {
        Consulta consulta = consultaMapper.toConsulta(consultaDTO);
        return consultaMapper.toConsultaDTO(consultaRepository.save(consulta));
    }

    @Override
    public ConsultaResponseDTO update(Long id, ConsultaRequestDTO consultaDTO) {
        Consulta consulta = returnConsulta(id);
        consultaMapper.updateConsultaData(consulta, consultaDTO);
        return consultaMapper.toConsultaDTO(consultaRepository.save(consulta));
    }

    @Override
    public String delete(Long id) {
        consultaRepository.deleteById(id);
        return "Consulta id: " + id + " deleted";
    }

    private Consulta returnConsulta(Long id) {
        return consultaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Consulta não encontrada no banco de dados"));
    }
}
