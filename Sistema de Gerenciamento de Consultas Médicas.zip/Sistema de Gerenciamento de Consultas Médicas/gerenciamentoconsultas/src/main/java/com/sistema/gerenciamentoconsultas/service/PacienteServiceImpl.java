package com.sistema.gerenciamentoconsultas.service;

import com.sistema.gerenciamentoconsultas.Dto.Request.PacienteRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.PacienteResponseDTO;
import com.sistema.gerenciamentoconsultas.Entities.Paciente;
import com.sistema.gerenciamentoconsultas.Repository.PacienteRepository;
import com.sistema.gerenciamentoconsultas.Util.PacienteMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PacienteServiceImpl implements PacienteService {

    private final PacienteRepository pacienteRepository;
    private final PacienteMapper pacienteMapper;

    @Override
    public PacienteResponseDTO findById(Long id) {
        Paciente paciente = returnPaciente(id);
        return pacienteMapper.toPacienteDTO(paciente);
    }

    @Override
    public List<PacienteResponseDTO> findAll() {
        List<Paciente> pacientes = pacienteRepository.findAll();
        return pacientes.stream().map(pacienteMapper::toPacienteDTO).collect(Collectors.toList());
    }

    @Override
    public PacienteResponseDTO register(PacienteRequestDTO pacienteDTO) {
        Paciente paciente = pacienteMapper.toPaciente(pacienteDTO);
        return pacienteMapper.toPacienteDTO(pacienteRepository.save(paciente));
    }

    @Override
    public PacienteResponseDTO update(Long id, PacienteRequestDTO pacienteDTO) {
        Paciente paciente = returnPaciente(id);
        pacienteMapper.updatePacienteData(paciente, pacienteDTO);
        return pacienteMapper.toPacienteDTO(pacienteRepository.save(paciente));
    }

    @Override
    public String delete(Long id) {
        pacienteRepository.deleteById(id);
        return "Paciente id: " + id + " deleted";
    }

    private Paciente returnPaciente(Long id) {
        return pacienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Paciente não encontrado no banco de dados"));
    }
}
