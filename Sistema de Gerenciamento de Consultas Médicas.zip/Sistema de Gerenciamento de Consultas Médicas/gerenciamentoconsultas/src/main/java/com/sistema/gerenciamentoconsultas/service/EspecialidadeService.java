package com.sistema.gerenciamentoconsultas.service;

import com.sistema.gerenciamentoconsultas.Dto.Request.EspecialidadeRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.EspecialidadeResponseDTO;

import java.util.List;

public interface EspecialidadeService {
    EspecialidadeResponseDTO findById(Long id);

    List<EspecialidadeResponseDTO> findAll();

    EspecialidadeResponseDTO register(EspecialidadeRequestDTO especialidadeDTO);

    EspecialidadeResponseDTO update(Long id, EspecialidadeRequestDTO especialidadeDTO);

    String delete(Long id);
}
