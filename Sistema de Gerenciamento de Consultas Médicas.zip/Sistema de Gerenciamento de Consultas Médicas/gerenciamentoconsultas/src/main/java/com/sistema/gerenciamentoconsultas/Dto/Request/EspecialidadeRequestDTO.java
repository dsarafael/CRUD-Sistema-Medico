package com.sistema.gerenciamentoconsultas.Dto.Request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EspecialidadeRequestDTO {
    private String nome;
    private String descricao;
}
