package com.sistema.gerenciamentoconsultas.Dto.Response;

import com.sistema.gerenciamentoconsultas.Entities.Especialidade;
import lombok.Getter;

@Getter
public class EspecialidadeResponseDTO {
    private Long id;
    private String nome;
    private String descricao;

    public EspecialidadeResponseDTO(Especialidade especialidade) {
        this.id = especialidade.getId();
        this.nome = especialidade.getNome();
        this.descricao = especialidade.getDescricao();
    }
}
