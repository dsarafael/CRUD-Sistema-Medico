package com.sistema.gerenciamentoconsultas.service;

import com.sistema.gerenciamentoconsultas.Dto.Request.MedicoRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.MedicoResponseDTO;
import com.sistema.gerenciamentoconsultas.Entities.Medico;
import com.sistema.gerenciamentoconsultas.Repository.MedicoRepository;
import com.sistema.gerenciamentoconsultas.Util.MedicoMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MedicoServiceImpl implements MedicoService {

    private final MedicoRepository medicoRepository;
    private final MedicoMapper medicoMapper;

    @Override
    public MedicoResponseDTO findById(Long id) {
        Medico medico = returnMedico(id);
        return medicoMapper.toMedicoDTO(medico);
    }

    @Override
    public List<MedicoResponseDTO> findAll() {
        List<Medico> medicos = medicoRepository.findAll();
        return medicos.stream().map(medicoMapper::toMedicoDTO).collect(Collectors.toList());
    }

    @Override
    public MedicoResponseDTO register(MedicoRequestDTO medicoDTO) {
        Medico medico = medicoMapper.toMedico(medicoDTO);
        return medicoMapper.toMedicoDTO(medicoRepository.save(medico));
    }

    @Override
    public MedicoResponseDTO update(Long id, MedicoRequestDTO medicoDTO) {
        Medico medico = returnMedico(id);
        medicoMapper.updateMedicoData(medico, medicoDTO);
        return medicoMapper.toMedicoDTO(medicoRepository.save(medico));
    }

    @Override
    public String delete(Long id) {
        medicoRepository.deleteById(id);
        return "Médico id: " + id + " deleted";
    }

    private Medico returnMedico(Long id) {
        return medicoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Médico não encontrado no banco de dados"));
    }
}
