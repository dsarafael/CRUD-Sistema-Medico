package com.sistema.gerenciamentoconsultas.Util;

import com.sistema.gerenciamentoconsultas.Dto.Request.EspecialidadeRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.EspecialidadeResponseDTO;
import com.sistema.gerenciamentoconsultas.Entities.Especialidade;
import org.springframework.stereotype.Component;

@Component
public class EspecialidadeMapper {

    public Especialidade toEspecialidade(EspecialidadeRequestDTO especialidadeDTO) {
        return Especialidade.builder()
                .nome(especialidadeDTO.getNome())
                .descricao(especialidadeDTO.getDescricao())
                .build();
    }

    public EspecialidadeResponseDTO toEspecialidadeDTO(Especialidade especialidade) {
        return new EspecialidadeResponseDTO(especialidade);
    }

    public void updateEspecialidadeData(Especialidade especialidade, EspecialidadeRequestDTO especialidadeDTO) {
        especialidade.setNome(especialidadeDTO.getNome());
        especialidade.setDescricao(especialidadeDTO.getDescricao());
    }
}
