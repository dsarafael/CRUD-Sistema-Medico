package com.sistema.gerenciamentoconsultas.Dto.Response;

import com.sistema.gerenciamentoconsultas.Entities.Consulta;
import lombok.Getter;

import java.util.Date;

@Getter
public class ConsultaResponseDTO {
    private Long id;
    private Long pacienteId;
    private Long medicoId;
    private Date dataConsulta;
    private String descricao;

    public ConsultaResponseDTO(Consulta consulta) {
        this.id = consulta.getId();
        this.pacienteId = consulta.getPaciente().getId();
        this.medicoId = consulta.getMedico().getId();
        this.dataConsulta = consulta.getDataConsulta();
        this.descricao = consulta.getDescricao();
    }
}
