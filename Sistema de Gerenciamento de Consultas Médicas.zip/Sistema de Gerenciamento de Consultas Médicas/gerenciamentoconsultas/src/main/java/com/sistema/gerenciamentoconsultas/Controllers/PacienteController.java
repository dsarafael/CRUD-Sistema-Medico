package com.sistema.gerenciamentoconsultas.Controllers;

import com.sistema.gerenciamentoconsultas.Dto.Request.PacienteRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.PacienteResponseDTO;
import com.sistema.gerenciamentoconsultas.service.PacienteService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pacientes")
@RequiredArgsConstructor
public class PacienteController {

    private final PacienteService pacienteService;

    @GetMapping("/{id}")
    public ResponseEntity<PacienteResponseDTO> findById(@PathVariable Long id) {
        PacienteResponseDTO paciente = pacienteService.findById(id);
        return ResponseEntity.ok(paciente);
    }

    @GetMapping
    public ResponseEntity<List<PacienteResponseDTO>> findAll() {
        List<PacienteResponseDTO> pacientes = pacienteService.findAll();
        return ResponseEntity.ok(pacientes);
    }

    @PostMapping
    public ResponseEntity<PacienteResponseDTO> register(@RequestBody PacienteRequestDTO pacienteRequestDTO) {
        PacienteResponseDTO novoPaciente = pacienteService.register(pacienteRequestDTO);
        return new ResponseEntity<>(novoPaciente, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PacienteResponseDTO> update(@PathVariable Long id, @RequestBody PacienteRequestDTO pacienteRequestDTO) {
        PacienteResponseDTO pacienteAtualizado = pacienteService.update(id, pacienteRequestDTO);
        return ResponseEntity.ok(pacienteAtualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        String response = pacienteService.delete(id);
        return ResponseEntity.ok(response);
    }
}
