package com.sistema.gerenciamentoconsultas.Dto.Response;

import com.sistema.gerenciamentoconsultas.Entities.Paciente;
import lombok.Getter;

import java.util.Date;

@Getter
public class PacienteResponseDTO {
    private Long id;
    private String nome;
    private String cpf;
    private Date dataNascimento;
    private String telefone;

    public PacienteResponseDTO(Paciente paciente) {
        this.id = paciente.getId();
        this.nome = paciente.getNome();
        this.cpf = paciente.getCpf();
        this.dataNascimento = paciente.getDataNascimento();
        this.telefone = paciente.getTelefone();
    }
}
