package com.sistema.gerenciamentoconsultas.Repository;

import com.sistema.gerenciamentoconsultas.Entities.Especialidade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EspecialidadeRepository extends JpaRepository<Especialidade, Long> {
    // Estende a interface JpaRepository, indicando que trata-se de um repositório para a entidade Especialidade
    // O segundo parâmetro <Especialidade, Long> indica que a entidade é Especialidade e o tipo da chave primária é Long
}
