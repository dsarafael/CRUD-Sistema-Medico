package com.sistema.gerenciamentoconsultas.Controllers;

import com.sistema.gerenciamentoconsultas.Dto.Request.MedicoRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.MedicoResponseDTO;
import com.sistema.gerenciamentoconsultas.service.MedicoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medicos")
@RequiredArgsConstructor
public class MedicoController {

    private final MedicoService medicoService;

    @GetMapping("/{id}")
    public ResponseEntity<MedicoResponseDTO> findById(@PathVariable Long id) {
        MedicoResponseDTO medico = medicoService.findById(id);
        return ResponseEntity.ok(medico);
    }

    @GetMapping
    public ResponseEntity<List<MedicoResponseDTO>> findAll() {
        List<MedicoResponseDTO> medicos = medicoService.findAll();
        return ResponseEntity.ok(medicos);
    }

    @PostMapping
    public ResponseEntity<MedicoResponseDTO> register(@RequestBody MedicoRequestDTO medicoRequestDTO) {
        MedicoResponseDTO novoMedico = medicoService.register(medicoRequestDTO);
        return new ResponseEntity<>(novoMedico, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MedicoResponseDTO> update(@PathVariable Long id, @RequestBody MedicoRequestDTO medicoRequestDTO) {
        MedicoResponseDTO medicoAtualizado = medicoService.update(id, medicoRequestDTO);
        return ResponseEntity.ok(medicoAtualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        String response = medicoService.delete(id);
        return ResponseEntity.ok(response);
    }
}
