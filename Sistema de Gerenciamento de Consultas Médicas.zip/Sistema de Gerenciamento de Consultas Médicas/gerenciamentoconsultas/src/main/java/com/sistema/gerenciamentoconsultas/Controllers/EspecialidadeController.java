package com.sistema.gerenciamentoconsultas.Controllers;

import com.sistema.gerenciamentoconsultas.Dto.Request.EspecialidadeRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.EspecialidadeResponseDTO;
import com.sistema.gerenciamentoconsultas.service.EspecialidadeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/especialidades")
@RequiredArgsConstructor
public class EspecialidadeController {

    private final EspecialidadeService especialidadeService;

    @GetMapping("/{id}")
    public ResponseEntity<EspecialidadeResponseDTO> findById(@PathVariable Long id) {
        EspecialidadeResponseDTO especialidade = especialidadeService.findById(id);
        return ResponseEntity.ok(especialidade);
    }

    @GetMapping
    public ResponseEntity<List<EspecialidadeResponseDTO>> findAll() {
        List<EspecialidadeResponseDTO> especialidades = especialidadeService.findAll();
        return ResponseEntity.ok(especialidades);
    }

    @PostMapping
    public ResponseEntity<EspecialidadeResponseDTO> register(@RequestBody EspecialidadeRequestDTO especialidadeRequestDTO) {
        EspecialidadeResponseDTO novaEspecialidade = especialidadeService.register(especialidadeRequestDTO);
        return new ResponseEntity<>(novaEspecialidade, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EspecialidadeResponseDTO> update(@PathVariable Long id, @RequestBody EspecialidadeRequestDTO especialidadeRequestDTO) {
        EspecialidadeResponseDTO especialidadeAtualizada = especialidadeService.update(id, especialidadeRequestDTO);
        return ResponseEntity.ok(especialidadeAtualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        String response = especialidadeService.delete(id);
        return ResponseEntity.ok(response);
    }
}
