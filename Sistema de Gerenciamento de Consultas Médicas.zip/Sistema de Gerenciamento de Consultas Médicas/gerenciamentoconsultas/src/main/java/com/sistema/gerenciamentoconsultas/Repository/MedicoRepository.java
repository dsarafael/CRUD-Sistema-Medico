package com.sistema.gerenciamentoconsultas.Repository;

import com.sistema.gerenciamentoconsultas.Entities.Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MedicoRepository extends JpaRepository<Medico, Long> {
    // Estende a interface JpaRepository, indicando que trata-se de um repositório para a entidade Medico
    // O segundo parâmetro <Medico, Long> indica que a entidade é Medico e o tipo da chave primária é Long
}
