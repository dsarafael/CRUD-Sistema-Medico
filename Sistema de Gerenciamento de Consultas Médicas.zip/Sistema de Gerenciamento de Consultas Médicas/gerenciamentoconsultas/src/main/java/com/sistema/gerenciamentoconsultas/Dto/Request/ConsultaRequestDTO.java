package com.sistema.gerenciamentoconsultas.Dto.Request;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class ConsultaRequestDTO {
    private Long pacienteId;
    private Long medicoId;
    private Date dataConsulta;
    private String descricao;
}
