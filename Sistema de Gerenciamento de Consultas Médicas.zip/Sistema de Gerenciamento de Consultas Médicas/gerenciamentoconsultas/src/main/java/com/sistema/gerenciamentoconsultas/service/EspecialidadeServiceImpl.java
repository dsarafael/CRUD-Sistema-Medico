package com.sistema.gerenciamentoconsultas.service;

import com.sistema.gerenciamentoconsultas.Dto.Request.EspecialidadeRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.EspecialidadeResponseDTO;
import com.sistema.gerenciamentoconsultas.Entities.Especialidade;
import com.sistema.gerenciamentoconsultas.Repository.EspecialidadeRepository;
import com.sistema.gerenciamentoconsultas.Util.EspecialidadeMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EspecialidadeServiceImpl implements EspecialidadeService {

    private final EspecialidadeRepository especialidadeRepository;
    private final EspecialidadeMapper especialidadeMapper;

    @Override
    public EspecialidadeResponseDTO findById(Long id) {
        Especialidade especialidade = returnEspecialidade(id);
        return especialidadeMapper.toEspecialidadeDTO(especialidade);
    }

    @Override
    public List<EspecialidadeResponseDTO> findAll() {
        List<Especialidade> especialidades = especialidadeRepository.findAll();
        return especialidades.stream().map(especialidadeMapper::toEspecialidadeDTO).collect(Collectors.toList());
    }

    @Override
    public EspecialidadeResponseDTO register(EspecialidadeRequestDTO especialidadeDTO) {
        Especialidade especialidade = especialidadeMapper.toEspecialidade(especialidadeDTO);
        return especialidadeMapper.toEspecialidadeDTO(especialidadeRepository.save(especialidade));
    }

    @Override
    public EspecialidadeResponseDTO update(Long id, EspecialidadeRequestDTO especialidadeDTO) {
        Especialidade especialidade = returnEspecialidade(id);
        especialidadeMapper.updateEspecialidadeData(especialidade, especialidadeDTO);
        return especialidadeMapper.toEspecialidadeDTO(especialidadeRepository.save(especialidade));
    }

    @Override
    public String delete(Long id) {
        especialidadeRepository.deleteById(id);
        return "Especialidade id: " + id + " deleted";
    }

    private Especialidade returnEspecialidade(Long id) {
        return especialidadeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Especialidade não encontrada no banco de dados"));
    }
}
