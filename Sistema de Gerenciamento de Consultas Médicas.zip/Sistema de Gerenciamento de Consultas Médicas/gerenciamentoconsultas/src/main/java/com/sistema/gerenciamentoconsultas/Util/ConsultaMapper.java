package com.sistema.gerenciamentoconsultas.Util;

import com.sistema.gerenciamentoconsultas.Dto.Request.ConsultaRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.ConsultaResponseDTO;
import com.sistema.gerenciamentoconsultas.Entities.Consulta;
import com.sistema.gerenciamentoconsultas.Entities.Medico;
import com.sistema.gerenciamentoconsultas.Entities.Paciente;
import com.sistema.gerenciamentoconsultas.Repository.MedicoRepository;
import com.sistema.gerenciamentoconsultas.Repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ConsultaMapper {

    @Autowired
    private PacienteRepository pacienteRepository;

    @Autowired
    private MedicoRepository medicoRepository;

    public Consulta toConsulta(ConsultaRequestDTO consultaDTO) {
        Paciente paciente = pacienteRepository.findById(consultaDTO.getPacienteId())
                .orElseThrow(() -> new RuntimeException("Paciente não encontrado"));
        Medico medico = medicoRepository.findById(consultaDTO.getMedicoId())
                .orElseThrow(() -> new RuntimeException("Médico não encontrado"));

        return Consulta.builder()
                .dataConsulta(consultaDTO.getDataConsulta())
                .paciente(paciente)
                .medico(medico)
                .descricao(consultaDTO.getDescricao())
                .build();
    }

    public ConsultaResponseDTO toConsultaDTO(Consulta consulta) {
        return new ConsultaResponseDTO(consulta);
    }

    public void updateConsultaData(Consulta consulta, ConsultaRequestDTO consultaDTO) {
        Paciente paciente = pacienteRepository.findById(consultaDTO.getPacienteId())
                .orElseThrow(() -> new RuntimeException("Paciente não encontrado"));
        Medico medico = medicoRepository.findById(consultaDTO.getMedicoId())
                .orElseThrow(() -> new RuntimeException("Médico não encontrado"));

        consulta.setDataConsulta(consultaDTO.getDataConsulta());
        consulta.setPaciente(paciente);
        consulta.setMedico(medico);
        consulta.setDescricao(consultaDTO.getDescricao());
    }
}
