package com.sistema.gerenciamentoconsultas.Util;

import com.sistema.gerenciamentoconsultas.Dto.Request.PacienteRequestDTO;
import com.sistema.gerenciamentoconsultas.Dto.Response.PacienteResponseDTO;
import com.sistema.gerenciamentoconsultas.Entities.Paciente;
import org.springframework.stereotype.Component;

@Component
public class PacienteMapper {

    public Paciente toPaciente(PacienteRequestDTO pacienteDTO) {
        return Paciente.builder()
                .nome(pacienteDTO.getNome())
                .cpf(pacienteDTO.getCpf())
                .dataNascimento(pacienteDTO.getDataNascimento())
                .telefone(pacienteDTO.getTelefone())
                .build();
    }

    public PacienteResponseDTO toPacienteDTO(Paciente paciente) {
        return new PacienteResponseDTO(paciente);
    }

    public void updatePacienteData(Paciente paciente, PacienteRequestDTO pacienteDTO) {
        paciente.setNome(pacienteDTO.getNome());
        paciente.setCpf(pacienteDTO.getCpf());
        paciente.setDataNascimento(pacienteDTO.getDataNascimento());
        paciente.setTelefone(pacienteDTO.getTelefone());
    }
}
